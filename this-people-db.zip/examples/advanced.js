/**
 * Advanced example — demonstrates complex queries, indexes, and bulk operations
 *
 * Run: node examples/advanced.js
 */

import Database from '../src/database.js';

async function main() {
  const db = new Database('advanced-demo', { saveInterval: 10_000 });
  await db.init();

  // ── Products table ──────────────────────────────────────────────────────
  const products = db.createTable('products', {
    name:     { type: 'string', required: true },
    price:    { type: 'number', required: true },
    category: { type: 'string', required: true },
    stock:    { type: 'number', default: 0 },
    rating:   { type: 'number', default: 0 },
    tags:     { type: 'array',  default: [] },
  });

  // Create an index on category for faster lookups
  products.createIndex('category');

  // ── Bulk insert ─────────────────────────────────────────────────────────
  products.insertMany([
    { name: 'Laptop',     price: 1200, category: 'electronics', stock: 15, rating: 4.5, tags: ['tech', 'portable'] },
    { name: 'Mouse',      price: 25,   category: 'electronics', stock: 100, rating: 4.2, tags: ['tech', 'input'] },
    { name: 'Keyboard',   price: 80,   category: 'electronics', stock: 50, rating: 4.0, tags: ['tech', 'input'] },
    { name: 'Desk Chair', price: 350,  category: 'furniture',   stock: 8,  rating: 4.7, tags: ['office', 'comfort'] },
    { name: 'Monitor',    price: 450,  category: 'electronics', stock: 20, rating: 4.3, tags: ['tech', 'display'] },
    { name: 'Notebook',   price: 5,    category: 'stationery',  stock: 200, rating: 3.8, tags: ['paper'] },
    { name: 'Pen Set',    price: 12,   category: 'stationery',  stock: 150, rating: 4.1, tags: ['writing'] },
    { name: 'Desk Lamp',  price: 45,   category: 'furniture',   stock: 30, rating: 4.4, tags: ['office', 'lighting'] },
    { name: 'Headphones', price: 150,  category: 'electronics', stock: 35, rating: 4.6, tags: ['tech', 'audio'] },
    { name: 'Backpack',   price: 65,   category: 'accessories', stock: 40, rating: 4.0, tags: ['travel', 'storage'] },
  ]);

  console.log(`Inserted ${products.count()} products\n`);

  // ── Complex queries ─────────────────────────────────────────────────────

  // $and implicit (multiple fields)
  console.log('── Electronics under $100 with stock > 30 ──');
  const result1 = products.find({
    where: { category: 'electronics', price: { $lt: 100 }, stock: { $gt: 30 } },
    order: { price: 'asc' },
  });
  console.log(result1.data.map(p => `  ${p.name}: $${p.price} (stock: ${p.stock})`).join('\n'));

  // $or
  console.log('\n── Products with rating >= 4.5 OR price < $10 ──');
  const result2 = products.find({
    where: { $or: [{ rating: { $gte: 4.5 } }, { price: { $lt: 10 } }] },
    order: { rating: 'desc' },
  });
  console.log(result2.data.map(p => `  ${p.name}: $${p.price} (rating: ${p.rating})`).join('\n'));

  // $regex
  console.log('\n── Products with "tech" in tags (via $regex on name) ──');
  const result3 = products.find({
    where: { name: { $regex: '^[LM]' } }, // names starting with L or M
  });
  console.log(result3.data.map(p => `  ${p.name}`).join('\n'));

  // $in with array field (tags)
  console.log('\n── Products tagged "office" ──');
  // Note: $in on array checks if the field value is in the given list
  // For array fields, we'd need a separate contains operator — but this works for scalar fields

  // Pagination
  console.log('\n── Products page 2 (offset 3, limit 3) ──');
  const page2 = products.find({ offset: 3, limit: 3, order: { name: 'asc' } });
  console.log(page2.data.map(p => `  ${p.name}: $${p.price}`).join('\n'));
  console.log(`  (showing ${page2.data.length} of ${page2.total} total)`);

  // ── Aggregation-like (manual) ───────────────────────────────────────────
  const allProducts = products.find().data;
  const byCategory = {};
  for (const p of allProducts) {
    if (!byCategory[p.category]) byCategory[p.category] = { count: 0, totalPrice: 0, avgRating: 0 };
    byCategory[p.category].count++;
    byCategory[p.category].totalPrice += p.price;
    byCategory[p.category].avgRating += p.rating;
  }
  console.log('\n── Category summary ──');
  for (const [cat, stats] of Object.entries(byCategory)) {
    stats.avgRating = (stats.avgRating / stats.count).toFixed(1);
    console.log(`  ${cat}: ${stats.count} products, avg price $${(stats.totalPrice / stats.count).toFixed(2)}, avg rating ${stats.avgRating}`);
  }

  // ── Save ────────────────────────────────────────────────────────────────
  await db.close();
  console.log('\n✓ Advanced demo saved.');
}

main().catch(console.error);