# ThisPeopleDB

**In-memory database from scratch** on Node.js with a custom query engine, JSON persistence, and an interactive REPL.

## Features

- 🗄️ **In-memory storage** — lightning fast, zero dependencies
- 🔍 **Custom query engine** — `WHERE`, `ORDER BY`, `LIMIT`, `OFFSET`, field selection
- 🧩 **Rich operators** — `$eq`, `$ne`, `$gt`, `$gte`, `$lt`, `$lte`, `$in`, `$nin`, `$like`, `$regex`, `$exists`, `$and`, `$or`
- 💾 **JSON persistence** — auto-saves every 30s (configurable) + saves on exit
- 📋 **Schema validation** — define types, required fields, defaults
- 🎮 **Interactive REPL** — SQL-like syntax for ad-hoc queries
- 🔗 **Fluent QueryBuilder API** — chain `.where()`, `.order()`, `.limit()`, `.offset()`, `.fields()`
- 📊 **Indexes** — create indexes on fields for faster lookups
- 🪶 **Zero dependencies** — pure Node.js

## Quick Start

```bash
# Start the REPL
node src/repl.js

# Run the demo
node src/index.js

# Run advanced example
node examples/advanced.js
```

## Programmatic API

```js
import Database from './src/database.js';

const db = new Database('mydb');
await db.init();

// Create table with schema
const users = db.createTable('users', {
  name:   { type: 'string', required: true },
  age:    { type: 'number', default: 0 },
  email:  { type: 'string' },
  role:   { type: 'string', default: 'user' },
  active: { type: 'boolean', default: true },
});

// Insert
users.insert({ name: 'Alice', age: 30, email: 'alice@test.com' });

// Query
users.find({ where: { age: { $gt: 25 } }, order: { name: 'asc' }, limit: 10 });

// Fluent API
db.query('users')
  .where({ active: true })
  .order({ name: 'asc' })
  .limit(5)
  .find();

// Update
users.update({ where: { name: 'Alice' } }, { age: 31 });

// Delete
users.delete({ where: { active: false } });

// Count
users.count({ role: 'admin' });

// Save & close
await db.close();
```

## REPL Commands

### Meta commands

| Command | Description |
|---------|-------------|
| `.tables` | List all tables |
| `.schema <table>` | Show table schema |
| `.save` | Force save to disk |
| `.load <path>` | Load from JSON file |
| `.help` | Show help |
| `.exit` / `.quit` | Exit |
| `.clear` | Clear screen |

### SQL-like queries

```sql
CREATE TABLE users (name string REQUIRED, age number DEFAULT 0, email string)
DROP TABLE users
INSERT INTO users (name, age) VALUES ('Alice', 30)
SELECT * FROM users WHERE age > 25 ORDER BY name ASC LIMIT 10
SELECT name, email FROM users WHERE role = 'admin'
UPDATE users SET age = 31 WHERE name = 'Alice'
DELETE FROM users WHERE age < 18
COUNT FROM users
```

### WHERE operators

`=`, `!=`, `<>`, `>`, `>=`, `<`, `<=`, `LIKE`, `IN (...)`, `NOT IN (...)`

Combine with `AND` / `OR`.

## Persistence

Data is stored in `./data/<db-name>.json`. Auto-save runs every 30 seconds (configurable via `saveInterval` option). Data is also saved on graceful shutdown.

## API Reference

### [`src/database.js`](src/database.js) — Core Engine

#### Utility Functions

| Function | Description |
|----------|-------------|
| [`generateId()`](src/database.js:63) | Generates a unique ID using timestamp + random suffix |
| [`cloneDeep(value)`](src/database.js:75) | Deep-clones a value via `JSON.parse(JSON.stringify(...))` |
| [`validateSchema(schema)`](src/database.js:90) | Validates a schema definition structure |
| [`validateRecord(schema, record)`](src/database.js:109) | Validates a record against its schema (types, required, defaults) |
| [`parseWhere(condition)`](src/database.js:159) | Normalizes a WHERE condition object |
| [`evaluateCondition(cond, record)`](src/database.js:173) | Evaluates a condition against a single record |
| [`parseOrder(orderSpec)`](src/database.js:256) | Normalizes an ORDER specification |
| [`applyOrder(records, orderSpec)`](src/database.js:285) | Sorts records by the given order specification |

#### Query Operators

| Operator | Description |
|----------|-------------|
| [`$eq`](src/database.js:173) | Equal to |
| [`$ne`](src/database.js:173) | Not equal to |
| [`$gt`](src/database.js:173) | Greater than |
| [`$gte`](src/database.js:173) | Greater than or equal |
| [`$lt`](src/database.js:173) | Less than |
| [`$lte`](src/database.js:173) | Less than or equal |
| [`$in`](src/database.js:173) | Value in array |
| [`$nin`](src/database.js:173) | Value not in array |
| [`$like`](src/database.js:173) | SQL-style pattern match (`%` wildcard) |
| [`$regex`](src/database.js:173) | Regular expression match |
| [`$exists`](src/database.js:173) | Field exists check |
| [`$and`](src/database.js:173) | Logical AND (array of conditions) |
| [`$or`](src/database.js:173) | Logical OR (array of conditions) |

#### `class Table`

Represents a single database table with schema enforcement and indexing.

| Method | Description |
|--------|-------------|
| [`constructor(name, schema, options)`](src/database.js:325) | Creates a new table. Options: `{ autoId: true }` |
| [`insert(data)`](src/database.js:373) | Inserts a record, returns the record with generated `id` |
| [`insertMany(dataArray)`](src/database.js:412) | Bulk inserts multiple records |
| [`get(id)`](src/database.js:426) | Retrieves a record by its `id` |
| [`find(query)`](src/database.js:451) | Queries records with `{ where, order, limit, offset, fields }` |
| [`findOne(query)`](src/database.js:492) | Returns the first matching record |
| [`update(query, changes)`](src/database.js:510) | Updates matching records, returns `{ modified }` count |
| [`delete(query)`](src/database.js:548) | Deletes matching records, returns `{ deleted }` count |
| [`count(where)`](src/database.js:577) | Counts records matching a condition |
| [`createIndex(field)`](src/database.js:598) | Creates an index on the specified field |
| [`toJSON()`](src/database.js:651) | Serializes the table for persistence |
| [`fromJSON(json)`](src/database.js:673) | Deserializes a table from JSON (static) |

#### `class Database`

Manages multiple tables with persistence and auto-save.

| Method | Description |
|--------|-------------|
| [`constructor(name, options)`](src/database.js:697) | Creates a database instance. Options: `{ saveDir, saveInterval }` |
| [`createTable(name, schema, options)`](src/database.js:738) | Creates and returns a new table |
| [`dropTable(name)`](src/database.js:761) | Drops a table by name |
| [`table(name)`](src/database.js:779) | Returns a table by name (throws if not found) |
| [`hasTable(name)`](src/database.js:795) | Checks if a table exists |
| [`listTables()`](src/database.js:808) | Returns an array of table names |
| [`save()`](src/database.js:826) | Persists all tables to disk (atomic write) |
| [`load()`](src/database.js:852) | Loads all tables from disk |
| [`close()`](src/database.js:902) | Saves and stops auto-save, cleans up |
| [`init()`](src/database.js:921) | Initializes: loads from disk, starts auto-save |
| [`query(tableName)`](src/database.js:942) | Returns a `QueryBuilder` for the given table |

#### `class QueryBuilder`

Fluent API for building and executing queries.

| Method | Description |
|--------|-------------|
| [`where(condition)`](src/database.js:975) | Sets the WHERE condition |
| [`order(orderSpec)`](src/database.js:986) | Sets the ORDER specification |
| [`limit(n)`](src/database.js:997) | Sets the maximum number of results |
| [`offset(n)`](src/database.js:1005) | Sets the number of records to skip |
| [`fields(fieldList)`](src/database.js:1013) | Sets the fields to return |
| [`find()`](src/database.js:1021) | Executes the query and returns results |
| [`findOne()`](src/database.js:1040) | Executes and returns the first match |
| [`count()`](src/database.js:1050) | Executes a count query |

### [`src/repl.js`](src/repl.js) — Interactive REPL

#### SQL Parser

| Function | Description |
|----------|-------------|
| [`tokenize(input)`](src/repl.js:83) | Tokenizes a SQL-like input string into tokens |
| [`parseValue(token)`](src/repl.js:135) | Parses a token into a typed JS value |
| [`parseFieldList(tokens, startIdx)`](src/repl.js:161) | Parses `(field1, field2, ...)` |
| [`parseValueList(tokens, startIdx)`](src/repl.js:185) | Parses `(val1, val2, ...)` with type coercion |
| [`parseWhereClause(tokens, startIdx)`](src/repl.js:211) | Parses `WHERE field op value [AND/OR ...]` |
| [`parseOrderBy(tokens, startIdx)`](src/repl.js:309) | Parses `ORDER BY field [ASC\|DESC] [, ...]` |
| [`parseLimitOffset(tokens, startIdx)`](src/repl.js:348) | Parses `LIMIT n [OFFSET n]` |

#### Command Executor & Display

| Function | Description |
|----------|-------------|
| [`executeSQL(db, input)`](src/repl.js:367) | Executes a SQL-like command against the database |
| [`formatTable(data, maxColWidth)`](src/repl.js:637) | Formats records as an ASCII table |
| [`countAnsi(str)`](src/repl.js:684) | Counts ANSI escape code characters |
| [`printResult(result)`](src/repl.js:689) | Displays a command result to the console |
| [`showHelp()`](src/repl.js:722) | Prints the interactive help screen |
| [`main()`](src/repl.js:820) | REPL entry point — starts the readline interface |

#### Supported SQL Commands

| Command | Syntax |
|---------|--------|
| CREATE TABLE | `CREATE TABLE name (field TYPE [REQUIRED] [DEFAULT val], ...)` |
| DROP TABLE | `DROP TABLE name` |
| INSERT INTO | `INSERT INTO name [(field, ...)] VALUES (val, ...)` |
| SELECT | `SELECT [field, ...] FROM name [WHERE ...] [ORDER BY ...] [LIMIT n] [OFFSET n]` |
| UPDATE | `UPDATE name SET field=val, ... [WHERE ...]` |
| DELETE | `DELETE FROM name [WHERE ...]` |
| COUNT | `COUNT FROM name [WHERE ...]` |

#### Meta-Commands

| Command | Description |
|---------|-------------|
| `.tables` | List all tables with record counts |
| `.schema <name>` | Show table schema as JSON |
| `.save` | Force-save database to disk |
| `.load <path>` | Load database from a JSON file |
| `.help` | Display help text |
| `.exit` / `.quit` | Exit the REPL (auto-saves) |
| `.clear` | Clear the terminal screen |

### [`src/index.js`](src/index.js) — Demo

| Function | Description |
|----------|-------------|
| [`main()`](src/index.js:51) | Demonstrates all API features: table creation, CRUD, queries, indexes, persistence |

## Project Structure

```
src/
  database.js    — Core engine: Database, Table, QueryBuilder, query parser (1063 lines)
  repl.js        — Interactive REPL with SQL-like syntax (950 lines)
  index.js       — Main entry point with demo (151 lines)
examples/
  advanced.js    — Advanced queries, indexes, bulk operations
data/            — JSON persistence files (auto-created)
```