/**
 * @fileoverview
 * ThisPeopleDB — Main entry point and comprehensive API demonstration.
 *
 * This script showcases all major features of the database engine:
 * table creation, schema validation, CRUD operations, query operators,
 * sorting, pagination, field selection, fluent QueryBuilder API,
 * and manual join-like queries.
 *
 * @package ThisPeopleDB
 * @module index
 * @author This People Studio
 *
 * @example
 * // Run the demo:
 * node src/index.js
 */

import Database from './database.js';

/**
 * Demonstrates the full ThisPeopleDB API.
 *
 * Creates a database with two tables (`users` and `posts`), inserts sample
 * records, and runs a series of query examples covering:
 *
 * - **Basic queries**: `find()`, `findOne()`, `get()`
 * - **WHERE filters**: `$eq`, `$gt`, `$in`, `$like`
 * - **Sorting**: `ORDER BY` with ascending/descending
 * - **Pagination**: `LIMIT` and `OFFSET`
 * - **Field selection**: projecting specific fields
 * - **Fluent API**: chaining `.where()`, `.order()`, `.limit()`
 * - **Updates**: bulk update with WHERE condition
 * - **Counting**: total and filtered counts
 * - **Deletion**: removing records by condition
 * - **Manual joins**: cross-table lookups via `get()`
 * - **Persistence**: auto-save and graceful shutdown
 *
 * @async
 * @returns {Promise<void>}
 *
 * @example
 * // Expected output structure:
 * // Inserted users: kf8a1x kf8a2y kf8a3z
 * // ── All users ──
 * // { data: [...], total: 3 }
 * // ...
 * // ✓ Database saved and closed.
 */
async function main() {
  // ── Create / open database ──────────────────────────────────────────────
  const db = new Database('thispeopledb', {
    saveInterval: 15_000, // auto-save every 15 seconds
  });
  await db.init();

  // ── Create tables ───────────────────────────────────────────────────────
  const users = db.createTable('users', {
    name:     { type: 'string',  required: true },
    age:      { type: 'number',  default: 0 },
    email:    { type: 'string' },
    role:     { type: 'string',  default: 'user' },
    active:   { type: 'boolean', default: true },
    tags:     { type: 'array',   default: [] },
    created:  { type: 'string',  default: () => new Date().toISOString() },
  });

  const posts = db.createTable('posts', {
    title:    { type: 'string',  required: true },
    content:  { type: 'string',  default: '' },
    authorId: { type: 'string',  required: true },
    views:    { type: 'number',  default: 0 },
    published:{ type: 'boolean', default: false },
  });

  // ── Insert data ─────────────────────────────────────────────────────────
  const alice = users.insert({ name: 'Alice', age: 30, email: 'alice@test.com', role: 'admin', tags: ['dev', 'admin'] });
  const bob   = users.insert({ name: 'Bob',   age: 25, email: 'bob@test.com', tags: ['dev'] });
  const charlie = users.insert({ name: 'Charlie', age: 35, email: 'charlie@test.com', role: 'moderator', active: false });

  console.log('Inserted users:', alice.id, bob.id, charlie.id);

  posts.insert({ title: 'Hello World', content: 'First post!', authorId: alice.id, published: true, views: 42 });
  posts.insert({ title: 'Node.js Tips', content: 'Some tips...', authorId: bob.id, published: true, views: 128 });
  posts.insert({ title: 'Draft Post', content: 'Not published yet', authorId: alice.id, published: false });

  // ── Query examples ──────────────────────────────────────────────────────

  // Simple find all
  console.log('\n── All users ──');
  console.log(users.find());

  // With WHERE
  console.log('\n── Active users ──');
  console.log(users.find({ where: { active: { $eq: true } } }));

  // Comparison operators
  console.log('\n── Users older than 28 ──');
  console.log(users.find({ where: { age: { $gt: 28 } } }));

  // $in operator
  console.log('\n── Users with role admin or moderator ──');
  console.log(users.find({ where: { role: { $in: ['admin', 'moderator'] } } }));

  // $like operator
  console.log('\n── Users whose name starts with "A" ──');
  console.log(users.find({ where: { name: { $like: 'A%' } } }));

  // ORDER BY
  console.log('\n── Users ordered by age descending ──');
  console.log(users.find({ order: { age: 'desc' } }));

  // LIMIT & OFFSET
  console.log('\n── First 2 users ──');
  console.log(users.find({ limit: 2 }));

  // Field selection
  console.log('\n── Only names and emails ──');
  console.log(users.find({ fields: ['name', 'email'] }));

  // Fluent QueryBuilder API
  console.log('\n── Fluent API: active users ordered by name ──');
  console.log(db.query('users').where({ active: true }).order({ name: 'asc' }).find());

  // Update
  console.log('\n── Update Bob to age 26 ──');
  console.log(users.update({ where: { name: 'Bob' } }, { age: 26 }));

  // Count
  console.log('\n── Total users:', users.count());
  console.log('── Active users:', users.count({ active: true }));

  // Delete
  console.log('\n── Delete Charlie ──');
  console.log(users.delete({ where: { name: 'Charlie' } }));

  // Join-like query (manual)
  console.log('\n── Posts with author names ──');
  const allPosts = posts.find().data;
  for (const post of allPosts) {
    const author = users.get(post.authorId);
    console.log(`  "${post.title}" by ${author ? author.name : 'Unknown'} (${post.views} views)`);
  }

  // ── Save & close ────────────────────────────────────────────────────────
  await db.close();
  console.log('\n✓ Database saved and closed.');
}

main().catch(console.error);