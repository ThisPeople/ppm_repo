/**
 * @fileoverview
 * ThisPeopleDB — In-memory database with JSON persistence and query engine.
 *
 * Core engine: manages tables, records, schema validation, indexing, and
 * automatic JSON persistence. Zero external dependencies.
 *
 * @package ThisPeopleDB
 * @module database
 * @author This People Studio
 */

import { promises as fs } from 'node:fs';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DEFAULT_DB_DIR = path.resolve(__dirname, '..', 'data');
const DEFAULT_SAVE_INTERVAL_MS = 30_000; // every 30 seconds

// ─── Helpers ────────────────────────────────────────────────────────────────

/**
 * Generates a unique record identifier.
 * Combines base-36 timestamp with random characters for collision resistance.
 *
 * @returns {string} A unique ID string (e.g. `"kf8a1x2b3c4d"`)
 * @example
 * generateId(); // → "kf8a1x2b3c4d"
 */
function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

/**
 * Deep-clones a value via JSON serialization.
 * NOTE: Functions, `undefined`, Symbols, and circular references are NOT preserved.
 *
 * @param {*} obj - Value to clone
 * @returns {*} Deep-cloned copy
 */
function cloneDeep(obj) {
  return JSON.parse(JSON.stringify(obj));
}

// ─── Schema validation ──────────────────────────────────────────────────────

/** @constant {string[]} Allowed schema field types */
const TYPES = ['string', 'number', 'boolean', 'array', 'object', 'null'];

/**
 * Validates a table schema definition.
 *
 * @param {Object} schema - Schema object where keys are field names
 * @param {Object} schema[field] - Field definition
 * @param {string} schema[field].type - Field type (must be one of {@link TYPES})
 * @throws {Error} If schema is not an object, or any field definition is invalid
 * @example
 * validateSchema({ name: { type: 'string', required: true } });
 */
function validateSchema(schema) {
  if (!schema || typeof schema !== 'object') {
    throw new Error('Schema must be an object');
  }
  for (const [field, def] of Object.entries(schema)) {
    if (!def || typeof def !== 'object') {
      throw new Error(`Schema field "${field}" must be an object with at least a "type"`);
    }
    if (!def.type || !TYPES.includes(def.type)) {
      throw new Error(`Schema field "${field}" has invalid type "${def.type}". Valid: ${TYPES.join(', ')}`);
    }
  }
}

/**
 * Validates a single record against a table schema.
 *
 * @param {Object} schema - Table schema definition
 * @param {Object} record - Record to validate
 * @returns {string[]} Array of validation error messages (empty if valid)
 * @example
 * const errors = validateRecord(
 *   { name: { type: 'string', required: true } },
 *   { name: 'Alice' }
 * );
 * // errors → []
 */
function validateRecord(schema, record) {
  const errors = [];
  for (const [field, def] of Object.entries(schema)) {
    const val = record[field];
    if (val === undefined || val === null) {
      if (def.required) {
        errors.push(`Field "${field}" is required`);
      }
      continue;
    }
    if (def.type === 'array' && !Array.isArray(val)) {
      errors.push(`Field "${field}" must be an array`);
    } else if (def.type === 'null' && val !== null) {
      errors.push(`Field "${field}" must be null`);
    } else if (!['array', 'object', 'null'].includes(def.type) && typeof val !== def.type) {
      errors.push(`Field "${field}" must be of type "${def.type}", got "${typeof val}"`);
    }
  }
  return errors;
}

// ─── Query parser ───────────────────────────────────────────────────────────

/**
 * Supported comparison operators for WHERE conditions.
 * @typedef {'$eq'|'$ne'|'$gt'|'$gte'|'$lt'|'$lte'|'$in'|'$nin'|'$like'|'$regex'|'$exists'} Operator
 */

/**
 * Supported logical operators for combining conditions.
 * @typedef {'$and'|'$or'} LogicalOperator
 */

/**
 * A single field condition, e.g. `{ $gt: 25 }`.
 * @typedef {Object} FieldCondition
 */

/**
 * A WHERE clause object mapping field names to conditions.
 * Supports nested logical operators `$and` / `$or`.
 * @typedef {Object} WhereClause
 * @property {FieldCondition|*} [fieldName] - Condition for a specific field
 * @property {WhereClause[]} [$and] - All sub-conditions must match
 * @property {WhereClause[]} [$or] - Any sub-condition must match
 */

/**
 * Parses a WHERE condition object into a filter function.
 *
 * Supports operators: {@link Operator $eq}, {@link Operator $ne $ne},
 * {@link Operator $gt $gt}, {@link Operator $gte $gte}, {@link Operator $lt $lt},
 * {@link Operator $lte $lte}, {@link Operator $in $in}, {@link Operator $nin $nin},
 * {@link Operator $like $like}, {@link Operator $regex $regex}, {@link Operator $exists $exists},
 * and logical combinators {@link LogicalOperator $and} / {@link LogicalOperator $or}.
 *
 * Shorthand: `{ age: 25 }` is equivalent to `{ age: { $eq: 25 } }`.
 *
 * @param {WhereClause} condition - Query condition object
 * @returns {function(Object): boolean} Predicate function that tests a record
 * @throws {Error} If an unknown operator is encountered
 *
 * @example
 * const fn = parseWhere({ age: { $gt: 25 }, role: { $in: ['admin', 'mod'] } });
 * fn({ age: 30, role: 'admin' }); // → true
 *
 * @example <caption>Logical $or</caption>
 * const fn = parseWhere({ $or: [{ role: 'admin' }, { age: { $lt: 18 } }] });
 */
function parseWhere(condition) {
  return function whereFn(record) {
    return evaluateCondition(condition, record);
  };
}

/**
 * Recursively evaluates a condition against a record.
 *
 * @param {WhereClause|Array} cond - Condition to evaluate
 * @param {Object} record - Record to test
 * @returns {boolean} Whether the record matches
 * @throws {Error} If an unknown operator is encountered
 */
function evaluateCondition(cond, record) {
  if (!cond || typeof cond !== 'object') return true;
  if (Array.isArray(cond)) return cond.some(c => evaluateCondition(c, record));

  const keys = Object.keys(cond);

  // Logical operators
  if (keys.length === 1 && keys[0] === '$and') {
    return cond.$and.every(c => evaluateCondition(c, record));
  }
  if (keys.length === 1 && keys[0] === '$or') {
    return cond.$or.some(c => evaluateCondition(c, record));
  }

  // Field conditions
  for (const field of keys) {
    if (field.startsWith('$')) continue;
    const value = record[field];
    const predicate = cond[field];

    if (predicate === null || predicate === undefined) {
      if (value !== predicate) return false;
      continue;
    }

    if (typeof predicate !== 'object' || predicate === null || Array.isArray(predicate)) {
      // shorthand $eq
      if (value !== predicate) return false;
      continue;
    }

    const opKeys = Object.keys(predicate);
    for (const op of opKeys) {
      const target = predicate[op];
      switch (op) {
        case '$eq':  if (value !== target) return false; break;
        case '$ne':  if (value === target) return false; break;
        case '$gt':  if (!(value > target)) return false; break;
        case '$gte': if (!(value >= target)) return false; break;
        case '$lt':  if (!(value < target)) return false; break;
        case '$lte': if (!(value <= target)) return false; break;
        case '$in':  if (!Array.isArray(target) || !target.includes(value)) return false; break;
        case '$nin': if (!Array.isArray(target) || target.includes(value)) return false; break;
        case '$like':
          if (typeof value !== 'string' || typeof target !== 'string') return false;
          const likePattern = target.replace(/%/g, '.*').replace(/_/g, '.');
          if (!new RegExp(`^${likePattern}$`, 'i').test(value)) return false;
          break;
        case '$regex':
          if (typeof value !== 'string' || typeof target !== 'string') return false;
          if (!new RegExp(target, 'i').test(value)) return false;
          break;
        case '$exists':
          if (target && (value === undefined)) return false;
          if (!target && (value !== undefined)) return false;
          break;
        default:
          throw new Error(`Unknown operator: ${op}`);
      }
    }
  }
  return true;
}

/**
 * Parses an ORDER BY specification into a normalized array.
 *
 * Accepts multiple formats:
 * - Object: `{ field: 'asc' | 'desc' }`
 * - Array of strings: `['field1', '-field2']` (prefix `-` means descending)
 * - Array of objects: `[{ field: 'name', dir: 'asc' }]`
 *
 * @param {Object|string[]|Object[]} orderSpec - Order specification
 * @returns {Array<{field: string, dir: 'asc'|'desc'}>} Normalized order entries
 *
 * @example
 * parseOrder({ age: 'desc' });
 * // → [{ field: 'age', dir: 'desc' }]
 *
 * @example
 * parseOrder(['name', '-age']);
 * // → [{ field: 'name', dir: 'asc' }, { field: 'age', dir: 'desc' }]
 */
function parseOrder(orderSpec) {
  if (Array.isArray(orderSpec)) {
    return orderSpec.map(s => {
      if (typeof s === 'string') {
        if (s.startsWith('-')) return { field: s.slice(1), dir: 'desc' };
        return { field: s, dir: 'asc' };
      }
      return s;
    });
  }
  if (typeof orderSpec === 'object' && orderSpec !== null) {
    return Object.entries(orderSpec).map(([field, dir]) => ({ field, dir }));
  }
  return [];
}

/**
 * Sorts an array of records according to an ORDER BY specification.
 * Uses stable sort. `undefined` values are sorted last.
 * String comparison uses `localeCompare`; other types use `<` / `>`.
 *
 * @param {Object[]} records - Records to sort
 * @param {Object|string[]|Object[]} orderSpec - Order specification (see {@link parseOrder})
 * @returns {Object[]} New sorted array (original is not mutated)
 *
 * @example
 * applyOrder([{ age: 30 }, { age: 25 }], { age: 'asc' });
 * // → [{ age: 25 }, { age: 30 }]
 */
function applyOrder(records, orderSpec) {
  const orders = parseOrder(orderSpec);
  if (orders.length === 0) return records;

  return [...records].sort((a, b) => {
    for (const { field, dir } of orders) {
      const va = a[field];
      const vb = b[field];
      if (va === undefined && vb === undefined) continue;
      if (va === undefined) return 1;
      if (vb === undefined) return -1;
      let cmp = 0;
      if (typeof va === 'string' && typeof vb === 'string') {
        cmp = va.localeCompare(vb);
      } else {
        cmp = va < vb ? -1 : va > vb ? 1 : 0;
      }
      if (cmp !== 0) return dir === 'desc' ? -cmp : cmp;
    }
    return 0;
  });
}

// ─── Table class ────────────────────────────────────────────────────────────

/**
 * Represents a single database table with schema validation, indexing,
 * and CRUD operations.
 *
 * Each record is stored as a deep-cloned object keyed by a unique string ID.
 * All returned data is deep-cloned to prevent accidental mutation.
 *
 * @example
 * const table = new Table('users', {
 *   name: { type: 'string', required: true },
 *   age:  { type: 'number', default: 0 },
 * });
 * table.insert({ name: 'Alice', age: 30 });
 * table.find({ where: { age: { $gt: 25 } } });
 */
class Table {
  /**
   * @param {string} name - Table name
   * @param {Object} [schema={}] - Schema definition (field name → type/constraints)
   * @param {Object} [schema[field].type] - Field type: `'string'`, `'number'`, `'boolean'`, `'array'`, `'object'`, `'null'`
   * @param {boolean} [schema[field].required] - Whether the field is required
   * @param {*|Function} [schema[field].default] - Default value (or factory function)
   * @param {Object} [options={}] - Table options
   * @param {Function} [options.dirtyCallback] - Called when data changes (for persistence)
   */
  constructor(name, schema = {}, options = {}) {
    /** @type {string} */
    this.name = name;
    /** @type {Object} */
    this.schema = schema;
    /** @type {Object} */
    this.options = options;
    /** @type {Map<string, Object>} id → record */
    this.records = new Map();
    /** @type {Map<string, Map<*, Set<string>>>} field → value → Set of IDs */
    this.indexes = new Map();
    /** @private */
    this._dirtyCallback = options.dirtyCallback || null;
  }

  /**
   * Marks the table as dirty (data changed), triggering the persistence callback.
   * @private
   */
  _markDirty() {
    if (this._dirtyCallback) this._dirtyCallback();
  }

  /**
   * Inserts a single record into the table.
   *
   * Applies schema defaults, validates against the schema, generates an ID
   * if none provided, and updates indexes.
   *
   * @param {Object} data - Record data
   * @param {string} [data.id] - Optional explicit ID (auto-generated if omitted)
   * @returns {Object} The inserted record (deep-cloned, with `id`)
   * @throws {Error} If validation fails or ID already exists
   *
   * @example
   * table.insert({ name: 'Alice', age: 30 });
   * // → { id: 'kf8a1x...', name: 'Alice', age: 30 }
   */
  insert(data) {
    const record = { ...data };
    // Apply defaults
    for (const [field, def] of Object.entries(this.schema)) {
      if (record[field] === undefined && def.default !== undefined) {
        record[field] = typeof def.default === 'function' ? def.default() : cloneDeep(def.default);
      }
    }
    // Validate
    const errors = validateRecord(this.schema, record);
    if (errors.length > 0) {
      throw new Error(`Validation failed for table "${this.name}": ${errors.join('; ')}`);
    }
    const id = record.id || generateId();
    if (this.records.has(id)) {
      throw new Error(`Duplicate id "${id}" in table "${this.name}"`);
    }
    record.id = id;
    const frozen = cloneDeep(record);
    this.records.set(id, frozen);
    this._updateIndexes(id, frozen);
    this._markDirty();
    return { id, ...frozen };
  }

  /**
   * Inserts multiple records in a single call.
   * Each record is individually validated (first failure stops the batch).
   *
   * @param {Object[]} dataArray - Array of record data objects
   * @returns {Object[]} Array of inserted records
   * @throws {Error} On first validation failure
   *
   * @example
   * table.insertMany([
   *   { name: 'Alice', age: 30 },
   *   { name: 'Bob', age: 25 },
   * ]);
   */
  insertMany(dataArray) {
    const results = dataArray.map(d => this.insert(d));
    return results;
  }

  /**
   * Retrieves a single record by its ID.
   *
   * @param {string} id - Record ID
   * @returns {Object|null} The record (deep-cloned), or `null` if not found
   *
   * @example
   * const user = table.get('kf8a1x...');
   */
  get(id) {
    const rec = this.records.get(id);
    return rec ? cloneDeep(rec) : null;
  }

  /**
   * Queries records with filtering, sorting, pagination, and field selection.
   *
   * @param {Object} [query={}] - Query parameters
   * @param {WhereClause} [query.where] - Filter conditions
   * @param {Object|string[]} [query.order] - Sort specification
   * @param {number} [query.limit] - Maximum records to return
   * @param {number} [query.offset] - Number of records to skip
   * @param {string[]} [query.fields] - Fields to include in results
   * @returns {{ data: Object[], total: number }} Results and total count (before pagination)
   *
   * @example
   * table.find({
   *   where: { age: { $gte: 18 }, active: true },
   *   order: { name: 'asc' },
   *   limit: 10,
   *   offset: 0,
   *   fields: ['name', 'email'],
   * });
   */
  find(query = {}) {
    const { where, order, limit, offset, fields } = query;
    let results = [...this.records.values()];

    if (where) {
      const filterFn = parseWhere(where);
      results = results.filter(filterFn);
    }

    if (order) {
      results = applyOrder(results, order);
    }

    const total = results.length;

    if (offset) results = results.slice(offset);
    if (limit) results = results.slice(0, limit);

    if (fields) {
      results = results.map(r => {
        const subset = {};
        for (const f of fields) {
          if (f in r) subset[f] = r[f];
        }
        return subset;
      });
    }

    return { data: cloneDeep(results), total };
  }

  /**
   * Finds a single record matching the query.
   * Equivalent to `find({ ...query, limit: 1 }).data[0]`.
   *
   * @param {Object} [query={}] - Query parameters (same as {@link Table#find})
   * @returns {Object|null} The first matching record, or `null`
   *
   * @example
   * table.findOne({ where: { email: 'alice@test.com' } });
   */
  findOne(query = {}) {
    const result = this.find({ ...query, limit: 1 });
    return result.data.length > 0 ? result.data[0] : null;
  }

  /**
   * Updates records matching the WHERE condition.
   *
   * @param {Object} query - Query with `where` condition
   * @param {WhereClause} [query.where] - Filter to select records to update
   * @param {Object} changes - Field/value pairs to apply (shallow merge)
   * @returns {{ modified: number }} Number of records modified
   * @throws {Error} If validation of updated records fails
   *
   * @example
   * table.update({ where: { name: 'Bob' } }, { age: 26 });
   * // → { modified: 1 }
   */
  update(query, changes) {
    const { where } = query;
    let count = 0;
    const idsToUpdate = [];

    for (const [id, rec] of this.records) {
      if (where && !parseWhere(where)(rec)) continue;
      idsToUpdate.push(id);
    }

    for (const id of idsToUpdate) {
      const oldRec = this.records.get(id);
      const newRec = { ...oldRec, ...changes, id };
      const errors = validateRecord(this.schema, newRec);
      if (errors.length > 0) {
        throw new Error(`Update validation failed for id "${id}": ${errors.join('; ')}`);
      }
      this.records.set(id, cloneDeep(newRec));
      this._removeFromIndexes(id, oldRec);
      this._updateIndexes(id, newRec);
      count++;
    }

    if (count > 0) this._markDirty();
    return { modified: count };
  }

  /**
   * Deletes records matching the WHERE condition.
   *
   * @param {Object} query - Query with `where` condition
   * @param {WhereClause} [query.where] - Filter to select records to delete
   * @returns {{ deleted: number }} Number of records deleted
   *
   * @example
   * table.delete({ where: { active: false } });
   * // → { deleted: 2 }
   */
  delete(query) {
    const { where } = query;
    const idsToDelete = [];

    for (const [id, rec] of this.records) {
      if (where && !parseWhere(where)(rec)) continue;
      idsToDelete.push(id);
    }

    for (const id of idsToDelete) {
      const rec = this.records.get(id);
      this._removeFromIndexes(id, rec);
      this.records.delete(id);
    }

    if (idsToDelete.length > 0) this._markDirty();
    return { deleted: idsToDelete.length };
  }

  /**
   * Counts records, optionally filtered by a WHERE condition.
   *
   * @param {WhereClause} [where] - Optional filter condition
   * @returns {number} Record count
   *
   * @example
   * table.count();               // → 100 (total)
   * table.count({ active: true }); // → 75
   */
  count(where) {
    if (!where) return this.records.size;
    const filterFn = parseWhere(where);
    let c = 0;
    for (const rec of this.records.values()) {
      if (filterFn(rec)) c++;
    }
    return c;
  }

  // ── Indexes ──────────────────────────────────────────────────────────────

  /**
   * Creates an index on the specified field for faster lookups.
   * Indexes are maintained automatically on insert/update/delete.
   *
   * @param {string} field - Field name to index
   *
   * @example
   * table.createIndex('email');
   */
  createIndex(field) {
    if (!this.indexes.has(field)) {
      this.indexes.set(field, new Map());
    }
    const idx = this.indexes.get(field);
    for (const [id, rec] of this.records) {
      const val = rec[field];
      if (val !== undefined) {
        if (!idx.has(val)) idx.set(val, new Set());
        idx.get(val).add(id);
      }
    }
  }

  /**
   * Updates all indexes when a record is inserted or updated.
   * @private
   * @param {string} id - Record ID
   * @param {Object} record - Record data
   */
  _updateIndexes(id, record) {
    for (const [field, idx] of this.indexes) {
      const val = record[field];
      if (val !== undefined) {
        if (!idx.has(val)) idx.set(val, new Set());
        idx.get(val).add(id);
      }
    }
  }

  /**
   * Removes a record from all indexes (used on update/delete).
   * @private
   * @param {string} id - Record ID
   * @param {Object} record - Old record data
   */
  _removeFromIndexes(id, record) {
    for (const [field, idx] of this.indexes) {
      const val = record[field];
      if (val !== undefined && idx.has(val)) {
        idx.get(val).delete(id);
        if (idx.get(val).size === 0) idx.delete(val);
      }
    }
  }

  // ── Serialization ────────────────────────────────────────────────────────

  /**
   * Serializes the table to a plain JSON-compatible object.
   *
   * @returns {Object} Serialized table data
   */
  toJSON() {
    return {
      name: this.name,
      schema: this.schema,
      options: this.options,
      records: [...this.records.values()],
    };
  }

  /**
   * Deserializes a table from a JSON object (inverse of {@link Table#toJSON}).
   *
   * @param {Object} json - Serialized table data
   * @param {string} json.name - Table name
   * @param {Object} json.schema - Schema definition
   * @param {Object} [json.options] - Table options
   * @param {Object[]} [json.records] - Array of record objects
   * @returns {Table} Restored Table instance
   *
   * @example
   * const table = Table.fromJSON(JSON.parse(jsonString));
   */
  static fromJSON(json) {
    const table = new Table(json.name, json.schema, json.options || {});
    for (const rec of json.records || []) {
      table.records.set(rec.id, cloneDeep(rec));
    }
    return table;
  }
}

// ─── Database class ─────────────────────────────────────────────────────────

/**
 * Manages multiple named tables with automatic JSON persistence.
 *
 * Provides table CRUD, schema validation, auto-save on interval,
 * and a fluent {@link QueryBuilder} API.
 *
 * @example
 * const db = new Database('mydb', { saveInterval: 10_000 });
 * await db.init();
 * const users = db.createTable('users', { name: { type: 'string', required: true } });
 * users.insert({ name: 'Alice' });
 * await db.close();
 */
class Database {
  /**
   * @param {string} [name='default'] - Database name (used for the JSON filename)
   * @param {Object} [options={}] - Database options
   * @param {string} [options.dbDir] - Directory for persistence files (default: `./data`)
   * @param {number} [options.saveInterval] - Auto-save interval in ms (default: 30000)
   */
  constructor(name = 'default', options = {}) {
    /** @type {string} */
    this.name = name;
    /** @type {Map<string, Table>} */
    this.tables = new Map();
    /** @type {string} */
    this.dbDir = options.dbDir || DEFAULT_DB_DIR;
    /** @type {number} */
    this.saveInterval = options.saveInterval ?? DEFAULT_SAVE_INTERVAL_MS;
    /** @private */
    this._saveTimer = null;
    /** @private */
    this._dirty = false;
    /** @private */
    this._closed = false;
  }

  // ── Table management ─────────────────────────────────────────────────────

  /**
   * Creates a new table with the given name and schema.
   *
   * @param {string} name - Table name
   * @param {Object} [schema={}] - Schema definition
   * @param {Object} [options={}] - Additional table options
   * @returns {Table} The newly created Table instance
   * @throws {Error} If table already exists or schema is invalid
   *
   * @example
   * const users = db.createTable('users', {
   *   name: { type: 'string', required: true },
   *   age:  { type: 'number', default: 0 },
   * });
   */
  createTable(name, schema = {}, options = {}) {
    if (this.tables.has(name)) {
      throw new Error(`Table "${name}" already exists`);
    }
    validateSchema(schema);
    const table = new Table(name, schema, {
      ...options,
      dirtyCallback: () => { this._dirty = true; },
    });
    this.tables.set(name, table);
    this._dirty = true;
    return table;
  }

  /**
   * Drops (removes) a table by name.
   *
   * @param {string} name - Table name to drop
   * @throws {Error} If table does not exist
   *
   * @example
   * db.dropTable('temp_data');
   */
  dropTable(name) {
    if (!this.tables.has(name)) {
      throw new Error(`Table "${name}" does not exist`);
    }
    this.tables.delete(name);
    this._dirty = true;
  }

  /**
   * Gets a table by name.
   *
   * @param {string} name - Table name
   * @returns {Table} The Table instance
   * @throws {Error} If table does not exist
   *
   * @example
   * const users = db.table('users');
   */
  table(name) {
    const t = this.tables.get(name);
    if (!t) throw new Error(`Table "${name}" does not exist`);
    return t;
  }

  /**
   * Checks if a table exists.
   *
   * @param {string} name - Table name
   * @returns {boolean} Whether the table exists
   */
  hasTable(name) {
    return this.tables.has(name);
  }

  /**
   * Lists all table names.
   *
   * @returns {string[]} Array of table names
   *
   * @example
   * db.listTables(); // → ['users', 'posts']
   */
  listTables() {
    return [...this.tables.keys()];
  }

  // ── Persistence ──────────────────────────────────────────────────────────

  /**
   * Full path to the JSON persistence file.
   * @type {string}
   */
  get dbPath() {
    return path.join(this.dbDir, `${this.name}.json`);
  }

  /**
   * Saves all tables to disk as a single JSON file.
   * Uses atomic write (write to `.tmp`, then rename).
   *
   * @returns {Promise<void>}
   *
   * @example
   * await db.save();
   */
  async save() {
    if (this._closed) return;
    await fs.mkdir(this.dbDir, { recursive: true });
    const data = {
      name: this.name,
      version: 1,
      savedAt: new Date().toISOString(),
      tables: {},
    };
    for (const [name, table] of this.tables) {
      data.tables[name] = table.toJSON();
    }
    const tmpPath = this.dbPath + '.tmp';
    await fs.writeFile(tmpPath, JSON.stringify(data, null, 2), 'utf-8');
    await fs.rename(tmpPath, this.dbPath);
    this._dirty = false;
  }

  /**
   * Loads database state from the JSON persistence file.
   *
   * @returns {Promise<boolean>} `true` if data was loaded, `false` if no file exists
   *
   * @example
   * const existed = await db.load();
   */
  async load() {
    if (!existsSync(this.dbPath)) return false;
    const raw = await fs.readFile(this.dbPath, 'utf-8');
    const data = JSON.parse(raw);
    for (const [name, tableJson] of Object.entries(data.tables || {})) {
      const table = Table.fromJSON(tableJson);
      table._dirtyCallback = () => { this._dirty = true; };
      this.tables.set(name, table);
    }
    this._dirty = false;
    return true;
  }

  /**
   * Starts the periodic auto-save timer.
   * @private
   */
  _startAutoSave() {
    if (this._saveTimer) clearInterval(this._saveTimer);
    this._saveTimer = setInterval(async () => {
      if (this._dirty && !this._closed) {
        try {
          await this.save();
        } catch (err) {
          console.error(`[DB] Auto-save error:`, err.message);
        }
      }
    }, this.saveInterval);
    if (this._saveTimer.unref) this._saveTimer.unref();
  }

  /**
   * Stops the periodic auto-save timer.
   * @private
   */
  _stopAutoSave() {
    if (this._saveTimer) {
      clearInterval(this._saveTimer);
      this._saveTimer = null;
    }
  }

  /**
   * Gracefully closes the database: stops auto-save and flushes pending changes.
   *
   * @returns {Promise<void>}
   *
   * @example
   * await db.close();
   */
  async close() {
    this._stopAutoSave();
    if (this._dirty) {
      await this.save();
    }
    this._closed = true;
  }

  // ── Init ─────────────────────────────────────────────────────────────────

  /**
   * Initializes the database: loads persisted data (if any) and starts auto-save.
   * Must be called before using the database.
   *
   * @returns {Promise<boolean>} `true` if existing data was loaded, `false` for a fresh database
   *
   * @example
   * await db.init();
   */
  async init() {
    const loaded = await this.load();
    this._startAutoSave();
    return loaded;
  }

  // ── Query helpers ────────────────────────────────────────────────────────

  /**
   * Creates a fluent {@link QueryBuilder} for the specified table.
   *
   * @param {string} tableName - Table name
   * @returns {QueryBuilder} A new QueryBuilder instance
   *
   * @example
   * db.query('users')
   *   .where({ active: true })
   *   .order({ name: 'asc' })
   *   .limit(10)
   *   .find();
   */
  query(tableName) {
    const table = this.table(tableName);
    return new QueryBuilder(table);
  }
}

// ─── QueryBuilder (fluent API) ──────────────────────────────────────────────

/**
 * Fluent query builder providing a chainable API for constructing queries.
 *
 * Created via {@link Database#query}. Each method returns `this` for chaining.
 *
 * @example
 * db.query('users')
 *   .where({ active: true })
 *   .order({ name: 'asc' })
 *   .limit(10)
 *   .offset(0)
 *   .fields(['name', 'email'])
 *   .find();
 */
class QueryBuilder {
  /**
   * @param {Table} table - The table to query against
   */
  constructor(table) {
    /** @private */
    this._table = table;
    /** @private */
    this._where = undefined;
    /** @private */
    this._order = undefined;
    /** @private */
    this._limit = undefined;
    /** @private */
    this._offset = undefined;
    /** @private */
    this._fields = undefined;
  }

  /**
   * Sets the WHERE filter condition.
   *
   * @param {WhereClause} condition - Filter conditions
   * @returns {QueryBuilder} This instance (for chaining)
   */
  where(condition) { this._where = condition; return this; }

  /**
   * Sets the ORDER BY specification.
   *
   * @param {Object|string[]} spec - Sort specification
   * @returns {QueryBuilder} This instance (for chaining)
   */
  order(spec) { this._order = spec; return this; }

  /**
   * Sets the maximum number of records to return.
   *
   * @param {number} n - Maximum records
   * @returns {QueryBuilder} This instance (for chaining)
   */
  limit(n) { this._limit = n; return this; }

  /**
   * Sets the number of records to skip (for pagination).
   *
   * @param {number} n - Records to skip
   * @returns {QueryBuilder} This instance (for chaining)
   */
  offset(n) { this._offset = n; return this; }

  /**
   * Sets the fields to include in results.
   *
   * @param {string[]} arr - Field names to include
   * @returns {QueryBuilder} This instance (for chaining)
   */
  fields(arr) { this._fields = arr; return this; }

  /**
   * Builds the query object from accumulated parameters.
   * @private
   * @returns {Object} Query object
   */
  _build() {
    return {
      where: this._where,
      order: this._order,
      limit: this._limit,
      offset: this._offset,
      fields: this._fields,
    };
  }

  /**
   * Executes the query and returns matching records.
   *
   * @returns {{ data: Object[], total: number }} Results and total count
   */
  find() { return this._table.find(this._build()); }

  /**
   * Executes the query and returns a single matching record.
   *
   * @returns {Object|null} The first matching record, or `null`
   */
  findOne() { return this._table.findOne(this._build()); }

  /**
   * Executes the query and returns the count of matching records.
   *
   * @returns {number} Record count
   */
  count() { return this._table.count(this._where); }
}

// ─── Exports ────────────────────────────────────────────────────────────────

export { Database, Table, QueryBuilder, generateId, cloneDeep };
export default Database;