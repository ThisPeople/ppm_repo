/**
 * @fileoverview
 * ThisPeopleDB — Interactive REPL (Read-Eval-Print-Loop)
 *
 * Provides a command-line interface with SQL-like syntax for ad-hoc database
 * operations. Supports meta-commands (`.tables`, `.schema`, etc.) and
 * SQL-style queries (SELECT, INSERT, UPDATE, DELETE, CREATE TABLE, etc.).
 *
 * @package ThisPeopleDB
 * @module repl
 * @author This People Studio
 *
 * @example
 * // Start the REPL:
 * node src/repl.js
 *
 * @example
 * // Example REPL session:
 * db> CREATE TABLE users (name string REQUIRED, age number DEFAULT 0)
 * db> INSERT INTO users (name, age) VALUES ('Alice', 30)
 * db> SELECT * FROM users WHERE age > 25
 * db> .exit
 */

import { createInterface } from 'node:readline';
import { promises as fs } from 'node:fs';
import { existsSync } from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import Database from './database.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ─── Color helpers ──────────────────────────────────────────────────────────

/**
 * ANSI color codes for terminal output.
 * @enum {string}
 * @private
 */
const colors = {
  reset: '\x1b[0m',
  bold: '\x1b[1m',
  dim: '\x1b[2m',
  red: '\x1b[31m',
  green: '\x1b[32m',
  yellow: '\x1b[33m',
  blue: '\x1b[34m',
  cyan: '\x1b[36m',
  gray: '\x1b[90m',
};

/**
 * Wraps text in an ANSI color code for terminal display.
 *
 * @param {string} text - Text to colorize
 * @param {string} color - Color name (key of {@link colors})
 * @returns {string} Colorized text with reset suffix
 *
 * @example
 * colorize('Hello', 'green'); // → '\x1b[32mHello\x1b[0m'
 */
function colorize(text, color) {
  return `${colors[color] || ''}${text}${colors.reset}`;
}

// ─── SQL-like parser ────────────────────────────────────────────────────────

/**
 * Tokenizes a SQL-like input string into an array of tokens.
 *
 * Handles quoted strings (single and double quotes), parentheses, commas,
 * equals signs, and whitespace-separated tokens.
 *
 * @param {string} input - Raw input string
 * @returns {string[]} Array of tokens
 *
 * @example
 * tokenize("SELECT * FROM users WHERE name = 'Alice'");
 * // → ['SELECT', '*', 'FROM', 'users', 'WHERE', 'name', '=', "'Alice'"]
 */
function tokenize(input) {
  const tokens = [];
  let i = 0;
  let current = '';
  let inQuote = null;

  while (i < input.length) {
    const ch = input[i];
    if (inQuote) {
      if (ch === inQuote) {
        inQuote = null;
        current += ch;
      } else {
        current += ch;
      }
    } else if (ch === "'" || ch === '"') {
      inQuote = ch;
      current += ch;
    } else if (ch === '(' || ch === ')' || ch === ',' || ch === '=') {
      if (current.trim()) tokens.push(current.trim());
      tokens.push(ch);
      current = '';
    } else if (/\s/.test(ch)) {
      if (current.trim()) tokens.push(current.trim());
      current = '';
    } else {
      current += ch;
    }
    i++;
  }
  if (current.trim()) tokens.push(current.trim());
  return tokens;
}

/**
 * Parses a token string into a typed JavaScript value.
 *
 * - Quoted strings → string (quotes removed)
 * - `'true'` / `'false'` → boolean
 * - `'null'` → `null`
 * - `'undefined'` → `undefined`
 * - Numeric strings → number
 * - Everything else → string
 *
 * @param {string} token - Token to parse
 * @returns {*} Parsed value
 *
 * @example
 * parseValue("'hello'"); // → 'hello'
 * parseValue('42');      // → 42
 * parseValue('true');    // → true
 */
function parseValue(token) {
  if (!token) return undefined;
  if ((token.startsWith("'") && token.endsWith("'")) ||
      (token.startsWith('"') && token.endsWith('"'))) {
    return token.slice(1, -1);
  }
  if (token === 'true') return true;
  if (token === 'false') return false;
  if (token === 'null') return null;
  if (token === 'undefined') return undefined;
  const num = Number(token);
  if (!isNaN(num) && token !== '') return num;
  return token;
}

/**
 * Parses a parenthesized field list: `(field1, field2, ...)`.
 *
 * @param {string[]} tokens - Token array
 * @param {number} startIdx - Index of the opening `(`
 * @returns {{ fields: string[]|null, nextIdx: number }} Parsed fields and next index
 *
 * @example
 * parseFieldList(['(', 'name', ',', 'age', ')'], 0);
 * // → { fields: ['name', 'age'], nextIdx: 5 }
 */
function parseFieldList(tokens, startIdx) {
  const fields = [];
  let i = startIdx;
  if (tokens[i] !== '(') return { fields: null, nextIdx: startIdx };
  i++;
  while (i < tokens.length && tokens[i] !== ')') {
    if (tokens[i] !== ',') fields.push(tokens[i]);
    i++;
  }
  return { fields, nextIdx: i + 1 };
}

/**
 * Parses a parenthesized value list: `(val1, val2, ...)`.
 * Each value is parsed via {@link parseValue}.
 *
 * @param {string[]} tokens - Token array
 * @param {number} startIdx - Index of the opening `(`
 * @returns {{ values: Array|null, nextIdx: number }} Parsed values and next index
 *
 * @example
 * parseValueList(['(', "'Alice'", ',', '30', ')'], 0);
 * // → { values: ['Alice', 30], nextIdx: 5 }
 */
function parseValueList(tokens, startIdx) {
  const values = [];
  let i = startIdx;
  if (tokens[i] !== '(') return { values: null, nextIdx: startIdx };
  i++;
  while (i < tokens.length && tokens[i] !== ')') {
    if (tokens[i] !== ',') values.push(parseValue(tokens[i]));
    i++;
  }
  return { values, nextIdx: i + 1 };
}

/**
 * Parses a WHERE clause from a token array.
 *
 * Supports operators: `=`, `!=`, `<>`, `>`, `>=`, `<`, `<=`, `LIKE`, `IN (...)`, `NOT IN (...)`
 * and combinators `AND` / `OR`.
 *
 * @param {string[]} tokens - Token array
 * @param {number} startIdx - Index where parsing should start (expected at `WHERE`)
 * @returns {{ condition: Object|null, nextIdx: number }} Parsed condition object and next index
 *
 * @example
 * parseWhereClause(['WHERE', 'age', '>', '25', 'AND', 'active', '=', 'true'], 0);
 * // → { condition: { age: { $gt: 25 }, active: { $eq: true } }, nextIdx: 8 }
 */
function parseWhereClause(tokens, startIdx) {
  if (startIdx >= tokens.length || tokens[startIdx].toUpperCase() !== 'WHERE') {
    return { condition: null, nextIdx: startIdx };
  }

  let i = startIdx + 1;
  const conditions = [];
  let currentLogic = '$and';

  while (i < tokens.length) {
    const field = tokens[i];
    if (!field) break;
    const upper = field.toUpperCase();
    if (upper === 'ORDER' || upper === 'LIMIT' || upper === 'OFFSET') break;
    if (upper === 'AND') { currentLogic = '$and'; i++; continue; }
    if (upper === 'OR') { currentLogic = '$or'; i++; continue; }

    const op = tokens[i + 1];
    if (!op) break;

    let operator = '$eq';
    let valToken;

    if (op === '=' || op === '==') {
      operator = '$eq';
      valToken = tokens[i + 2];
      i += 3;
    } else if (op === '!=' || op === '<>') {
      operator = '$ne';
      valToken = tokens[i + 2];
      i += 3;
    } else if (op === '>') {
      operator = '$gt';
      valToken = tokens[i + 2];
      i += 3;
    } else if (op === '>=') {
      operator = '$gte';
      valToken = tokens[i + 2];
      i += 3;
    } else if (op === '<') {
      operator = '$lt';
      valToken = tokens[i + 2];
      i += 3;
    } else if (op === '<=') {
      operator = '$lte';
      valToken = tokens[i + 2];
      i += 3;
    } else if (op.toUpperCase() === 'LIKE') {
      operator = '$like';
      valToken = tokens[i + 2];
      i += 3;
    } else if (op.toUpperCase() === 'IN') {
      operator = '$in';
      const { values, nextIdx } = parseValueList(tokens, i + 2);
      valToken = values;
      i = nextIdx;
    } else if (op.toUpperCase() === 'NOT') {
      if (tokens[i + 2] && tokens[i + 2].toUpperCase() === 'IN') {
        operator = '$nin';
        const { values, nextIdx } = parseValueList(tokens, i + 3);
        valToken = values;
        i = nextIdx;
      } else {
        break;
      }
    } else {
      operator = '$eq';
      valToken = op;
      i += 2;
    }

    conditions.push({ field, operator, value: parseValue(valToken) });
  }

  if (conditions.length === 0) return { condition: null, nextIdx: startIdx };

  const condition = {};
  for (const c of conditions) {
    if (!condition[c.field]) condition[c.field] = {};
    condition[c.field][c.operator] = c.value;
  }

  return { condition, nextIdx: i };
}

/**
 * Parses an ORDER BY clause from a token array.
 *
 * Supports: `ORDER BY field [ASC|DESC] [, field2 ...]`
 *
 * @param {string[]} tokens - Token array
 * @param {number} startIdx - Index where parsing should start (expected at `ORDER`)
 * @returns {{ order: Array<{field: string, dir: string}>|null, nextIdx: number }} Parsed order spec and next index
 *
 * @example
 * parseOrderBy(['ORDER', 'BY', 'name', 'ASC', ',', 'age', 'DESC'], 0);
 * // → { order: [{ field: 'name', dir: 'asc' }, { field: 'age', dir: 'desc' }], nextIdx: 7 }
 */
function parseOrderBy(tokens, startIdx) {
  if (startIdx >= tokens.length || tokens[startIdx].toUpperCase() !== 'ORDER') {
    return { order: null, nextIdx: startIdx };
  }
  let i = startIdx + 1;
  if (tokens[i] && tokens[i].toUpperCase() === 'BY') i++;

  const order = [];
  while (i < tokens.length) {
    const upper = tokens[i].toUpperCase();
    if (upper === 'LIMIT' || upper === 'OFFSET' || upper === 'WHERE') break;
    const field = tokens[i];
    i++;
    if (i < tokens.length && tokens[i].toUpperCase() === 'ASC') {
      order.push({ field, dir: 'asc' });
      i++;
    } else if (i < tokens.length && tokens[i].toUpperCase() === 'DESC') {
      order.push({ field, dir: 'desc' });
      i++;
    } else {
      order.push({ field, dir: 'asc' });
    }
    if (i < tokens.length && tokens[i] === ',') i++;
  }

  return { order, nextIdx: i };
}

/**
 * Parses LIMIT and OFFSET clauses from a token array.
 *
 * @param {string[]} tokens - Token array
 * @param {number} startIdx - Index where parsing should start
 * @returns {{ limit: number|null, offset: number|null, nextIdx: number }} Parsed values and next index
 *
 * @example
 * parseLimitOffset(['LIMIT', '10', 'OFFSET', '5'], 0);
 * // → { limit: 10, offset: 5, nextIdx: 4 }
 */
function parseLimitOffset(tokens, startIdx) {
  let limit = null;
  let offset = null;
  let i = startIdx;

  if (i < tokens.length && tokens[i].toUpperCase() === 'LIMIT') {
    limit = parseInt(tokens[i + 1], 10);
    i += 2;
  }
  if (i < tokens.length && tokens[i].toUpperCase() === 'OFFSET') {
    offset = parseInt(tokens[i + 1], 10);
    i += 2;
  }

  return { limit, offset, nextIdx: i };
}

// ─── Command executor ───────────────────────────────────────────────────────

/**
 * Executes a SQL-like command against the database.
 *
 * Parses the input string into tokens, identifies the command type, and
 * dispatches to the appropriate handler. Supports the following commands:
 *
 * | Command | Description |
 * |---------|-------------|
 * | `CREATE TABLE` | Creates a new table with schema definition |
 * | `DROP TABLE` | Drops an existing table |
 * | `INSERT INTO` | Inserts a new record |
 * | `SELECT` | Queries records with optional WHERE/ORDER/LIMIT/OFFSET |
 * | `UPDATE` | Modifies records matching a condition |
 * | `DELETE` | Removes records matching a condition |
 * | `COUNT` | Counts records matching a condition |
 *
 * Schema field modifiers: `REQUIRED` (or `NOT NULL`), `DEFAULT <value>`.
 * Supported types: `string`, `number`, `boolean`, `array`, `object`, `null`.
 *
 * @param {Database} db - Database instance to operate on
 * @param {string} input - Raw SQL-like input string
 * @returns {{ type: string, message?: string, data?: Object, total?: number, table?: string, count?: number }}
 *          Result object with a `type` property:
 *          - `'success'`: operation succeeded, `message` contains description
 *          - `'select'`: SELECT result, `data` contains rows, `total` total count
 *          - `'count'`: COUNT result, `count` contains the number
 *          - `'error'`: operation failed, `message` contains error details
 *          - `'empty'`: no input provided
 *
 * @example
 * executeSQL(db, "CREATE TABLE users (name string REQUIRED, age number DEFAULT 0)");
 * // → { type: 'success', message: 'Table "users" created' }
 *
 * @example
 * executeSQL(db, "SELECT * FROM users WHERE age > 25");
 * // → { type: 'select', data: [...], total: 5, table: 'users' }
 */
function executeSQL(db, input) {
  const tokens = tokenize(input.trim());
  if (tokens.length === 0) return { type: 'empty' };

  const cmd = tokens[0].toUpperCase();

  try {
    switch (cmd) {
      // ── CREATE TABLE ────────────────────────────────────────────────────
      case 'CREATE': {
        if (tokens[1]?.toUpperCase() !== 'TABLE') {
          return { type: 'error', message: 'Expected CREATE TABLE' };
        }
        const tableName = tokens[2];
        if (!tableName) return { type: 'error', message: 'Missing table name' };

        const schema = {};
        // Parse (field TYPE, field2 TYPE2, ...)
        let i = 3;
        if (tokens[i] === '(') i++;
        while (i < tokens.length && tokens[i] !== ')') {
          const field = tokens[i];
          const type = tokens[i + 1]?.toLowerCase() || 'string';
          // Check for modifiers
          let required = false;
          let defaultValue = undefined;
          let j = i + 2;
          while (j < tokens.length && tokens[j] !== ',' && tokens[j] !== ')') {
            const mod = tokens[j].toUpperCase();
            if (mod === 'REQUIRED' || mod === 'NOT' && tokens[j + 1]?.toUpperCase() === 'NULL') {
              required = true;
              if (tokens[j + 1]?.toUpperCase() === 'NULL') j++;
            } else if (mod === 'DEFAULT') {
              defaultValue = parseValue(tokens[j + 1]);
              j++;
            }
            j++;
          }
          schema[field] = { type, required, default: defaultValue };
          i = j;
          if (tokens[i] === ',') i++;
        }

        db.createTable(tableName, schema);
        return { type: 'success', message: `Table "${tableName}" created` };
      }

      // ── DROP TABLE ──────────────────────────────────────────────────────
      case 'DROP': {
        if (tokens[1]?.toUpperCase() !== 'TABLE') {
          return { type: 'error', message: 'Expected DROP TABLE' };
        }
        const tableName = tokens[2];
        if (!tableName) return { type: 'error', message: 'Missing table name' };
        db.dropTable(tableName);
        return { type: 'success', message: `Table "${tableName}" dropped` };
      }

      // ── INSERT INTO ─────────────────────────────────────────────────────
      case 'INSERT': {
        if (tokens[1]?.toUpperCase() !== 'INTO') {
          return { type: 'error', message: 'Expected INSERT INTO' };
        }
        const tableName = tokens[2];
        if (!tableName) return { type: 'error', message: 'Missing table name' };

        let i = 3;
        let fields = null;
        let values = null;

        if (tokens[i] === '(') {
          const parsed = parseFieldList(tokens, i);
          fields = parsed.fields;
          i = parsed.nextIdx;
        }

        if (tokens[i]?.toUpperCase() === 'VALUES') {
          i++;
          const parsed = parseValueList(tokens, i);
          values = parsed.values;
          i = parsed.nextIdx;
        }

        if (!values) return { type: 'error', message: 'Missing VALUES' };

        let record;
        if (fields) {
          record = {};
          for (let j = 0; j < fields.length; j++) {
            record[fields[j]] = values[j];
          }
        } else {
          // No fields specified — assume all fields in order
          record = values;
        }

        const result = db.table(tableName).insert(record);
        return { type: 'success', message: `Inserted 1 row (id: ${result.id})`, data: result };
      }

      // ── SELECT ──────────────────────────────────────────────────────────
      case 'SELECT': {
        let i = 1;
        let fields = ['*'];

        if (tokens[i] !== '*') {
          // Parse field list
          const flds = [];
          while (i < tokens.length && tokens[i].toUpperCase() !== 'FROM') {
            if (tokens[i] !== ',') flds.push(tokens[i]);
            i++;
          }
          if (flds.length > 0) fields = flds;
        } else {
          i++; // skip *
        }

        if (tokens[i]?.toUpperCase() !== 'FROM') {
          return { type: 'error', message: 'Expected FROM' };
        }
        i++;

        const tableName = tokens[i];
        if (!tableName) return { type: 'error', message: 'Missing table name' };
        i++;

        const { condition, nextIdx: whereEnd } = parseWhereClause(tokens, i);
        i = whereEnd;
        const { order, nextIdx: orderEnd } = parseOrderBy(tokens, i);
        i = orderEnd;
        const { limit, offset, nextIdx: limitEnd } = parseLimitOffset(tokens, i);

        const query = {};
        if (condition) query.where = condition;
        if (order) query.order = order;
        if (limit) query.limit = limit;
        if (offset) query.offset = offset;
        if (fields.length > 0 && !(fields.length === 1 && fields[0] === '*')) {
          query.fields = fields;
        }

        const result = db.table(tableName).find(query);
        return { type: 'select', data: result.data, total: result.total, table: tableName };
      }

      // ── UPDATE ──────────────────────────────────────────────────────────
      case 'UPDATE': {
        const tableName = tokens[1];
        if (!tableName) return { type: 'error', message: 'Missing table name' };

        if (tokens[2]?.toUpperCase() !== 'SET') {
          return { type: 'error', message: 'Expected SET' };
        }

        let i = 3;
        const changes = {};
        while (i < tokens.length) {
          const upper = tokens[i].toUpperCase();
          if (upper === 'WHERE') break;
          const field = tokens[i];
          if (tokens[i + 1] !== '=') {
            return { type: 'error', message: `Expected '=' after "${field}"` };
          }
          const value = parseValue(tokens[i + 2]);
          changes[field] = value;
          i += 3;
          if (tokens[i] === ',') i++;
        }

        const { condition } = parseWhereClause(tokens, i);
        const result = db.table(tableName).update({ where: condition }, changes);
        return { type: 'success', message: `Updated ${result.modified} row(s)` };
      }

      // ── DELETE ──────────────────────────────────────────────────────────
      case 'DELETE': {
        if (tokens[1]?.toUpperCase() !== 'FROM') {
          return { type: 'error', message: 'Expected DELETE FROM' };
        }
        const tableName = tokens[2];
        if (!tableName) return { type: 'error', message: 'Missing table name' };

        let i = 3;
        const { condition } = parseWhereClause(tokens, i);
        const result = db.table(tableName).delete({ where: condition });
        return { type: 'success', message: `Deleted ${result.deleted} row(s)` };
      }

      // ── COUNT ───────────────────────────────────────────────────────────
      case 'COUNT': {
        if (tokens[1]?.toUpperCase() !== 'FROM') {
          return { type: 'error', message: 'Expected COUNT FROM' };
        }
        const tableName = tokens[2];
        if (!tableName) return { type: 'error', message: 'Missing table name' };

        let i = 3;
        const { condition } = parseWhereClause(tokens, i);
        const count = db.table(tableName).count(condition);
        return { type: 'count', count, table: tableName };
      }

      default:
        return { type: 'error', message: `Unknown command: ${cmd}` };
    }
  } catch (err) {
    return { type: 'error', message: err.message };
  }
}

// ─── Display helpers ────────────────────────────────────────────────────────

/**
 * Formats an array of records into a monospaced ASCII table for terminal display.
 *
 * Automatically computes column widths based on the longest value in each column,
 * capped at `maxColWidth`. Renders a header row with column names, a separator
 * line, and data rows. `null` values are displayed in gray via ANSI color codes.
 *
 * @param {Array<Object>} data - Array of record objects to display
 * @param {number} [maxColWidth=60] - Maximum width for any column in characters
 * @returns {string} Formatted table string, or `'(empty)'` if data is empty
 *
 * @example
 * formatTable([{ name: 'Alice', age: 30 }, { name: 'Bob', age: 25 }]);
 * // Returns:
 * // +-------+-----+
 * // | name  | age |
 * // +-------+-----+
 * // | Alice | 30  |
 * // | Bob   | 25  |
 * // +-------+-----+
 */
function formatTable(data, maxColWidth = 60) {
  if (!data || data.length === 0) return '(empty)';

  const columns = [...new Set(data.flatMap(Object.keys))];
  const colWidths = columns.map(col =>
    Math.min(
      Math.max(
        col.length,
        ...data.map(r => {
          const v = r[col];
          const s = v === null ? 'null' : v === undefined ? '' : String(v);
          return s.length;
        })
      ),
      maxColWidth
    )
  );

  const separator = '+-' + columns.map((c, i) => '-'.repeat(colWidths[i]) + '-').join('+-') + '+';

  const formatRow = (row, isHeader = false) => {
    const cells = columns.map((col, i) => {
      let val;
      if (isHeader) {
        val = col;
      } else {
        const v = row[col];
        val = v === null ? colorize('null', 'gray') : v === undefined ? '' : String(v);
      }
      const s = isHeader ? val : val;
      const pad = colWidths[i] - (isHeader ? col.length : String(val).length - (isHeader ? 0 : countAnsi(val)));
      return ' ' + s + ' '.repeat(Math.max(0, pad)) + ' ';
    });
    return '|' + cells.join('|') + '|';
  };

  const lines = [];
  lines.push(separator);
  lines.push(formatRow(null, true));
  lines.push(separator);
  for (const row of data) {
    lines.push(formatRow(row));
  }
  lines.push(separator);
  return lines.join('\n');
}

/**
 * Counts the total character length of ANSI escape codes in a string.
 *
 * Used by {@link formatTable} to correctly compute visible column widths
 * when colorized values are present, since ANSI codes have zero visual width
 * but occupy characters in the string.
 *
 * @param {string} str - String potentially containing ANSI escape sequences
 * @returns {number} Total length of all ANSI escape codes found
 *
 * @example
 * countAnsi('\x1b[32mHello\x1b[0m'); // → 10 (two codes: 5 chars each)
 */
function countAnsi(str) {
  return (str.match(/\x1b\[[0-9;]*m/g) || []).join('').length;
}

/**
 * Displays a command execution result to the console.
 *
 * Handles all result types produced by {@link executeSQL}:
 * - `'success'`: green checkmark with message, optionally followed by a formatted table
 * - `'select'`: formatted table with row count summary, or yellow "(0 rows)" message
 * - `'count'`: cyan count value
 * - `'error'`: red error message with cross mark
 * - Other types: silently ignored
 *
 * @param {{ type: string, message?: string, data?: Array<Object>, total?: number, table?: string, count?: number }} result
 *        Result object from {@link executeSQL}
 *
 * @example
 * printResult({ type: 'success', message: 'Table "users" created' });
 * // Output: ✓ Table "users" created (in green)
 *
 * @example
 * printResult({ type: 'select', data: [...], total: 5, table: 'users' });
 * // Output: formatted table + "(3 of 5 rows)" (in dim)
 */
function printResult(result) {
  switch (result.type) {
    case 'success':
      console.log(colorize(`✓ ${result.message}`, 'green'));
      if (result.data) {
        console.log(formatTable([result.data]));
      }
      break;

    case 'select':
      if (result.data.length === 0) {
        console.log(colorize(`(0 rows from "${result.table}")`, 'yellow'));
      } else {
        console.log(formatTable(result.data));
        console.log(colorize(`(${result.data.length} of ${result.total} rows)`, 'dim'));
      }
      break;

    case 'count':
      console.log(colorize(`Count: ${result.count}`, 'cyan'));
      break;

    case 'error':
      console.log(colorize(`✗ Error: ${result.message}`, 'red'));
      break;

    default:
      break;
  }
}

// ─── REPL ───────────────────────────────────────────────────────────────────

/**
 * Displays the interactive help text to the console.
 *
 * Prints a formatted help screen covering:
 * - Meta-commands (`.tables`, `.schema`, `.save`, `.load`, `.help`, `.exit`, `.clear`)
 * - SQL-like query syntax (CREATE TABLE, DROP TABLE, INSERT, SELECT, UPDATE, DELETE, COUNT)
 * - WHERE clause operators and combinators
 * - ORDER BY syntax
 * - Usage examples
 *
 * Uses ANSI color codes via {@link colorize} for section headers and highlighting.
 *
 * @example
 * showHelp();
 * // Output: formatted help text with all commands and examples
 */
function showHelp() {
  console.log(`
${colorize('ThisPeopleDB — Interactive REPL', 'bold')}

${colorize('Meta commands:', 'yellow')}
  .tables              List all tables
  .schema <table>      Show table schema
  .save                Force save to disk
  .load <path>         Load from a specific JSON file
  .help                Show this help
  .exit / .quit        Exit
  .clear               Clear screen

${colorize('SQL-like queries:', 'cyan')}
  CREATE TABLE <name> (field TYPE, field2 TYPE2, ...)
    Types: string, number, boolean, array, object, null
    Modifiers: REQUIRED, DEFAULT <val>

  DROP TABLE <name>

  INSERT INTO <name> (field1, field2) VALUES (val1, val2)
  INSERT INTO <name> VALUES (val1, val2)

  SELECT * FROM <name> [WHERE ...] [ORDER BY ...] [LIMIT n] [OFFSET n]
  SELECT field1, field2 FROM <name> [...]

  UPDATE <name> SET field=val, field2=val2 [WHERE ...]

  DELETE FROM <name> [WHERE ...]

  COUNT FROM <name> [WHERE ...]

${colorize('WHERE operators:', 'yellow')}
  =, !=, <>, >, >=, <, <=, LIKE, IN (val1, val2), NOT IN (val1, val2)
  Combine with AND / OR

${colorize('ORDER BY:', 'yellow')}
  ORDER BY field [ASC|DESC] [, field2 ...]

${colorize('Examples:', 'green')}
  CREATE TABLE users (name string REQUIRED, age number DEFAULT 0, email string)
  INSERT INTO users (name, age, email) VALUES ('Alice', 30, 'alice@test.com')
  SELECT * FROM users WHERE age > 25 ORDER BY name ASC
  UPDATE users SET age=31 WHERE name='Alice'
  DELETE FROM users WHERE age < 18
  COUNT FROM users
`);
}

/**
 * REPL (Read-Eval-Print-Loop) entry point.
 *
 * Initializes the database, sets up a `readline` interface, and enters an
 * interactive loop that processes user input. Handles two categories of input:
 *
 * **Meta-commands** (prefixed with `.`):
 * - `.tables` — list all tables with record counts
 * - `.schema <name>` — show table schema as JSON
 * - `.save` — force-save database to disk
 * - `.load <path>` — load database from a JSON file
 * - `.help` — display help text
 * - `.exit` / `.quit` — exit the REPL (auto-saves on close)
 * - `.clear` — clear the terminal screen
 *
 * **SQL-like commands** (no prefix):
 * - Delegated to {@link executeSQL} and displayed via {@link printResult}
 *
 * On REPL close (Ctrl+C, `.exit`), the database is automatically saved before exit.
 *
 * @async
 * @returns {Promise<void>}
 *
 * @example
 * // Start the REPL from the command line:
 * node src/repl.js
 *
 * @example
 * // Programmatic usage (not recommended — use the CLI):
 * import repl from './repl.js';
 * // The module runs main() automatically when executed directly
 */
async function main() {
  const db = new Database('thispeopledb');
  await db.init();

  console.log(colorize(`\n  ╔══════════════════════════════════════╗`, 'cyan'));
  console.log(colorize(`  ║     ThisPeopleDB — In-Memory DB      ║`, 'cyan'));
  console.log(colorize(`  ║     Type .help for commands          ║`, 'cyan'));
  console.log(colorize(`  ╚══════════════════════════════════════╝\n`, 'cyan'));

  const rl = createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: colorize('db> ', 'bold'),
    historySize: 100,
  });

  rl.on('close', async () => {
    console.log(colorize('\nSaving data before exit...', 'yellow'));
    await db.close();
    console.log(colorize('Bye!', 'green'));
    process.exit(0);
  });

  rl.prompt();

  rl.on('line', async (line) => {
    const input = line.trim();

    if (!input) {
      rl.prompt();
      return;
    }

    // Meta commands
    if (input.startsWith('.')) {
      const parts = input.slice(1).split(/\s+/);
      const metaCmd = parts[0].toLowerCase();

      switch (metaCmd) {
        case 'help':
          showHelp();
          break;

        case 'tables': {
          const tables = db.listTables();
          if (tables.length === 0) {
            console.log(colorize('No tables', 'yellow'));
          } else {
            console.log(colorize('Tables:', 'bold'));
            for (const t of tables) {
              const table = db.table(t);
              console.log(`  ${colorize('📋', 'cyan')} ${colorize(t, 'bold')} (${table.records.size} records)`);
            }
          }
          break;
        }

        case 'schema': {
          const tableName = parts[1];
          if (!tableName) {
            console.log(colorize('Usage: .schema <table_name>', 'yellow'));
            break;
          }
          try {
            const table = db.table(tableName);
            console.log(colorize(`Schema for "${tableName}":`, 'bold'));
            console.log(JSON.stringify(table.schema, null, 2));
          } catch (err) {
            console.log(colorize(`Error: ${err.message}`, 'red'));
          }
          break;
        }

        case 'save':
          await db.save();
          console.log(colorize('✓ Data saved to disk', 'green'));
          break;

        case 'load': {
          const loadPath = parts[1];
          if (!loadPath) {
            console.log(colorize('Usage: .load <path_to_json>', 'yellow'));
            break;
          }
          try {
            const fullPath = path.resolve(loadPath);
            const raw = await fs.readFile(fullPath, 'utf-8');
            const data = JSON.parse(raw);
            // Clear existing tables and load
            for (const name of db.listTables()) db.dropTable(name);
            for (const [name, tableJson] of Object.entries(data.tables || {})) {
              const { Table } = await import('./database.js');
              const table = Table.fromJSON(tableJson);
              db.tables.set(name, table);
            }
            console.log(colorize(`✓ Loaded from ${fullPath}`, 'green'));
          } catch (err) {
            console.log(colorize(`Error loading: ${err.message}`, 'red'));
          }
          break;
        }

        case 'exit':
        case 'quit':
          rl.close();
          return;

        case 'clear':
          console.clear();
          break;

        default:
          console.log(colorize(`Unknown meta command: ${input}`, 'red'));
          break;
      }

      rl.prompt();
      return;
    }

    // SQL-like commands
    const result = executeSQL(db, input);
    printResult(result);
    rl.prompt();
  });
}

main().catch(err => {
  console.error('Fatal error:', err);
  process.exit(1);
});